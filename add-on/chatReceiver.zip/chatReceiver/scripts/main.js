import { world, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";

let loginInterval = {};
let playerData = new Map();
let pendingLogin = new Set()

world.beforeEvents.chatSend.subscribe((event) => {

    const player = event.sender;
    const message = event.message;
    console.warn(`[CHAT] ${player.name}: ${message}`);
})

world.afterEvents.playerSpawn.subscribe(ev => {
    const player = ev.player;
    if (!loginInterval[player.name]) {
        loginInterval[player.name] = Date.now();
        console.warn(`[LOGIN] ${player.name} : ${loginInterval[player.name]}`);
    }
    /*if (!playerData.has(player.name)) {
        playerData.set(player.name, {
            login: false,
        });
        player.addEffect("slowness", 999999, { amplifier: 255});
        player.addEffect("mining_fatigue", 999999, { amplifier: 255});
        player.addEffect("blindness", 999999, { amplifier: 1});
        player.addEffect("regeneration", 999999, { amplifier: 10});
        player.addEffect("resistance", 999999, { amplifier: 255, showParticles: false});
        pendingLogin.add(player.name);
        system.runTimeout(() => showForm(player), 20);
    } else if (playerData.get(player.name).login === true) {
        unlockPlayer(player);
        if (pendingLogin.has(player.name)) pendingLogin.delete(player.name)
    } else if(playerData.get(player.name).login === false) {
        pendingLogin.add(player.name);
        system.runTimeout(() => showForm(player), 20);
    }*/
})

world.afterEvents.playerLeave.subscribe(ev => {
    const player = ev.playerName;
    const loginTime = loginInterval[player];
    //if (pendingLogin.has(player)) pendingLogin.delete(player);

    if (loginTime) {
        const sessionDuration = Math.floor((Date.now() - loginTime) / 1000);
        delete loginInterval[player];

        console.warn(`[LOGOUT] ${player} : ${sessionDuration}`);
    }
})

async function showForm(player) {
    if (!world.getPlayers().some(p => p.id === player.id)) return;
    if (!pendingLogin.has(player.name)) return;
    const form = new ModalFormData()
        .title("§c🔐 Server Login")
        .textField("Masukan nomormu yang ada di Grup", "628...");

        let response;
        try {
            response = await form.show(player);
        } catch (e) {
            pendingLogin.delete(player.name);
            return;
        }
            
        if (response.canceled) {
            if (!world.getPlayers().some(p => p.id === player.id)) return;
            player.sendMessage("§cLogin dibatalkan.");
            system.runTimeout(() => showForm(player), 20);
            return;
        }
        const phoneNumber = response.formValues[0].trim();
        const data = playerData.get(player.name);
        let duplicate = false;
        for (const [key, value] of playerData.entries()) {
            if(value.phone === phoneNumber && key !== player.name) {
                duplicate = true;
                break
            }
        }
    if (duplicate) {
        player.sendMessage("§cNomor tersebut sudah digunakan oleh pemain lain!");
        system.runTimeout(() => showForm(player), 40);
        return;
    }
        if(!phoneNumber.startsWith("628")) {
            if (!world.getPlayers().some(p => p.id === player.id)) return;
            player.sendMessage("§cNomor tidak valid. Harus diawali dengan 628.");
            system.runTimeout(() => showForm(player), 40);
            return;
        }
            data.phone = phoneNumber;
            data.otp = Math.floor(100000 + Math.random() * 900000).toString();
            console.warn(`[PHONE] ${player.name} : ${phoneNumber} : ${data.otp}`);
            player.sendMessage("§aNomor valid. Silakan lanjut ke OTP.");
            //unlockPlayer(player);
            system.runTimeout(() => otpForm(player), 100);
    
}

async function otpForm(player) {
    if (!world.getPlayers().some(p => p.id === player.id)) return;
    const formOTP = new ModalFormData()
        .title("§q🔐 OTP Verification")
        .textField("Masukkan OTP ", "123456");

        let responseOTP;
        try {
            
         responseOTP = await formOTP.show(player);
        } catch (e) {
            pendingLogin.delete(player.name);
            return;
        }
        if (responseOTP.canceled) {
            if (!world.getPlayers().some(p => p.id === player.id)) return;
            player.sendMessage("§cVerifikasi OTP dibatalkan.");
            system.runTimeout(() => otpForm(player), 100);
            return;
        }
        const enteredOTP = responseOTP.formValues[0].trim();
        const data = playerData.get(player.name);
        if(enteredOTP !== data.otp) {
            if (!world.getPlayers().some(p => p.id === player.id)) return;
            player.sendMessage("§cOTP salah. Silakan coba lagi.");
            system.runTimeout(() => otpForm(player), 60);
        } else {
            player.sendMessage("§aOTP benar. Selamat bermain!");
            data.login = true;
            pendingLogin.delete(player.name);
            unlockPlayer(player);
        }
}

function unlockPlayer(player) {
    player.runCommand("effect @s clear");
    player.addEffect("resistance", 80, { amplifier: 255, showParticles: true});
}