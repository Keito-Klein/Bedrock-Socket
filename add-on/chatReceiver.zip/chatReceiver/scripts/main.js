import { world, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";

let loginInterval = {};
let playerData = new Map();
let pendingLogin = new Set()
//config coreprotect
const inspectCooldown = new Map();
const INSPECTOR = "minecraft:stick";
const MAX_HISTORY_PER_BLOCK = 25;
const INSPECT_DELAY = 500;

/*=========================[HANDLE INTERACTION WITH BLOCK]=========================*/
world.afterEvents.playerInteractWithBlock.subscribe((event) => {
    const player = event.player;
    const block = event.block;
    if(!block) return;

    const id = block.typeId;
    if(!id.includes("chest") && !id.includes("door")) return;
    const key = getBlockKey(block);
    const oldHistory = getAllHistory();
    const allHistory = { ...oldHistory }
    if(!allHistory[key]) {
        allHistory[key] = [];
    }

    let action = ""
    if(id.includes("door")) {
        const isOpen = block.permutation.getState("open_bit")
        action = isOpen ? "opened door" : "closed door"
    }

    if (id.includes("chest")) {
        action = "opened chest";
    }

    const blockLogs = [...allHistory[key]]

    blockLogs.push({
        player: player.name,
        action,
        time: Date.now()
    })

    if(blockLogs.length > MAX_HISTORY_PER_BLOCK) {
        blockLogs.shift();
    }
    allHistory[key] = blockLogs;
    saveAllHistory(allHistory);
})

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const player = event.player;
    const block = event.block;
    if(!block) return;

    const inven = player.getComponent("inventory")?.container;
    if(!inven) return;
    const item = inven.getItem(player.selectedSlotIndex);
    if(!item) return;
    if(!player.isSneaking) return;
    if(item.typeId !== INSPECTOR) return;
    const now = Date.now();
    const lastUse = inspectCooldown.get(player.id)
    if (lastUse && now - lastUse < INSPECT_DELAY) {
        return;
    }
    inspectCooldown.set(player.id, now)

    event.cancel = true;
    const key = getBlockKey(block);
    const allHistory = getAllHistory();
    if(!allHistory[key] || allHistory[key].length === 0) {
        player.sendMessage("§cTidak ada riwayat untuk block ini.")
        return;
    }
    player.sendMessage("§e=== Riwayat Block ===")

    for(const log of allHistory[key]) {
        const date = new Date(log.time);
        const timeStr = `${date.getDate()}/${date.getMonth() +1} ${date.getHours()}:${date.getMinutes()}`
        player.sendMessage(`§7[${timeStr}] §a${log.player} §f${log.action}`)
    }
})


world.beforeEvents.chatSend.subscribe((event) => {

    const player = event.sender;
    const message = event.message;
    console.info(`[CHAT] ${player.name}: ${message}`);
})

world.afterEvents.playerSpawn.subscribe(ev => {
    const player = ev.player;
    if (!loginInterval[player.name]) {
        loginInterval[player.name] = Date.now();
        console.warn(`[LOGIN] ${player.name} : ${loginInterval[player.name]}`);
    }
    /*if (!playerData.has(player.name)) {
        playerData.set(player.name, {
            login: false,
        });
        player.addEffect("slowness", 999999, { amplifier: 255});
        player.addEffect("mining_fatigue", 999999, { amplifier: 255});
        player.addEffect("blindness", 999999, { amplifier: 1});
        player.addEffect("regeneration", 999999, { amplifier: 10});
        player.addEffect("resistance", 999999, { amplifier: 255, showParticles: false});
        pendingLogin.add(player.name);
        system.runTimeout(() => showForm(player), 20);
    } else if (playerData.get(player.name).login === true) {
        unlockPlayer(player);
        if (pendingLogin.has(player.name)) pendingLogin.delete(player.name)
    } else if(playerData.get(player.name).login === false) {
        pendingLogin.add(player.name);
        system.runTimeout(() => showForm(player), 20);
    }*/
})

world.afterEvents.playerLeave.subscribe(ev => {
    const player = ev.playerName;
    const loginTime = loginInterval[player];
    //if (pendingLogin.has(player)) pendingLogin.delete(player);

    if (loginTime) {
        const sessionDuration = Math.floor((Date.now() - loginTime) / 1000);
        delete loginInterval[player];

        console.warn(`[LOGOUT] ${player} : ${sessionDuration}`);
    }
})

world.afterEvents.entityDie.subscribe((event) => {
    const dead = event.deadEntity;
    if(dead.typeId !== "minecraft:player") return;

    const player = dead;
    const dimension = player.dimension.id.replace("minecraft:", "");
    const loc = player.location;
    const x = Math.floor(loc.x);
    const y = Math.floor(loc.y);
    const z = Math.floor(loc.z);

    let cause = "unknown"
    const  dmgSource = event.damageSource;
    if(dmgSource) {
        if(dmgSource.damagingEntity) {
            cause = `slain by ${dmgSource.damagingEntity.typeId.replace("minecraft:", "")}`
        } else if(dmgSource.cause) {
            cause = dmgSource.cause;
        }
    }

    const message = `[DEATH] ${player.name} caused ${cause} on ${x} ${y} ${z} dimension ${dimension}`
    console.warn(message);
})


/*============[FUNCTION]============*/
function getAllHistory() {
    const rawData = world.getDynamicProperty("block_history");
    if(!rawData) return {};
    try{
        return JSON.parse(rawData);
    } catch {
        return {}
    }
}

function saveAllHistory(data) {
    world.setDynamicProperty("block_history", JSON.stringify(data));
}

function getBlockKey(block) {
    const { x, y, z } = block.location;
    const dimension = block.dimension.id;
    return `${dimension}:${x}:${y}:${z}`
}

async function showForm(player) {
    if (!world.getPlayers().some(p => p.id === player.id)) return;
    if (!pendingLogin.has(player.name)) return;
    const form = new ModalFormData()
        .title("§c🔐 Server Login")
        .textField("Masukan nomormu yang ada di Grup", "628...");

        let response;
        try {
            response = await form.show(player);
        } catch (e) {
            pendingLogin.delete(player.name);
            return;
        }
            
        if (response.canceled) {
            if (!world.getPlayers().some(p => p.id === player.id)) return;
            player.sendMessage("§cLogin dibatalkan.");
            system.runTimeout(() => showForm(player), 20);
            return;
        }
        const phoneNumber = response.formValues[0].trim();
        const data = playerData.get(player.name);
        let duplicate = false;
        for (const [key, value] of playerData.entries()) {
            if(value.phone === phoneNumber && key !== player.name) {
                duplicate = true;
                break
            }
        }
    if (duplicate) {
        player.sendMessage("§cNomor tersebut sudah digunakan oleh pemain lain!");
        system.runTimeout(() => showForm(player), 40);
        return;
    }
        if(!phoneNumber.startsWith("628")) {
            if (!world.getPlayers().some(p => p.id === player.id)) return;
            player.sendMessage("§cNomor tidak valid. Harus diawali dengan 628.");
            system.runTimeout(() => showForm(player), 40);
            return;
        }
            data.phone = phoneNumber;
            data.otp = Math.floor(100000 + Math.random() * 900000).toString();
            console.warn(`[PHONE] ${player.name} : ${phoneNumber} : ${data.otp}`);
            player.sendMessage("§aNomor valid. Silakan lanjut ke OTP.");
            //unlockPlayer(player);
            system.runTimeout(() => otpForm(player), 100);
    
}

async function otpForm(player) {
    if (!world.getPlayers().some(p => p.id === player.id)) return;
    const formOTP = new ModalFormData()
        .title("§q🔐 OTP Verification")
        .textField("Masukkan OTP ", "123456");

        let responseOTP;
        try {
            
         responseOTP = await formOTP.show(player);
        } catch (e) {
            pendingLogin.delete(player.name);
            return;
        }
        if (responseOTP.canceled) {
            if (!world.getPlayers().some(p => p.id === player.id)) return;
            player.sendMessage("§cVerifikasi OTP dibatalkan.");
            system.runTimeout(() => otpForm(player), 100);
            return;
        }
        const enteredOTP = responseOTP.formValues[0].trim();
        const data = playerData.get(player.name);
        if(enteredOTP !== data.otp) {
            if (!world.getPlayers().some(p => p.id === player.id)) return;
            player.sendMessage("§cOTP salah. Silakan coba lagi.");
            system.runTimeout(() => otpForm(player), 60);
        } else {
            player.sendMessage("§aOTP benar. Selamat bermain!");
            data.login = true;
            pendingLogin.delete(player.name);
            unlockPlayer(player);
        }
}

function unlockPlayer(player) {
    player.runCommand("effect @s clear");
    player.addEffect("resistance", 80, { amplifier: 255, showParticles: true});
}